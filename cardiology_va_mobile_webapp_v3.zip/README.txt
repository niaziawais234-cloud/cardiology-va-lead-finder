CARDIOLOGY / MEDICAL VA LEAD FINDER — MOBILE WEB APP v3

This is the mobile-friendly version. It runs as a small local web server and
can be opened in a phone browser when the server is running.

FILES
  server.py  - backend
  index.html - mobile interface

INSTALL
  Python 3.9+
  pip install requests beautifulsoup4

RUN
  python server.py

Then open:
  http://localhost:8080

For PHONE-ONLY use, a cloud deployment is needed (e.g. a free Python hosting
environment). The app itself does not require a paid API key.

SAFETY / PRIVACY
The app searches public web information and extracts public business contact
information. It does not log into Upwork, bypass CAPTCHAs/anti-bot systems,
or attempt to discover private/personal email addresses. Verify leads before
outreach and follow applicable website terms and laws.

NOTE
Search-engine HTML changes frequently. If Google blocks automated requests,
the app may return few/no results. A production version should use a permitted
search API or another compliant public-search provider.
