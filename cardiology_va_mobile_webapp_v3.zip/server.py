from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs, quote_plus
import json,re,html
from urllib.request import Request,urlopen
from bs4 import BeautifulSoup

UA="Mozilla/5.0 (compatible; CardiologyVALeadFinder/3.0)"
EMAIL_RE=re.compile(r"(?i)\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b")
PHONE_RE=re.compile(r"(?<!\d)(?:\+?1[\s.-]?)?\(?[2-9]\d{2}\)?[\s.-]\d{3}[\s.-]\d{4}(?!\d)")
FREE={"gmail.com","outlook.com","hotmail.com","yahoo.com","icloud.com","aol.com","proton.me","protonmail.com","live.com","msn.com"}

def get(url,timeout=12):
    req=Request(url,headers={"User-Agent":UA})
    return urlopen(req,timeout=timeout).read().decode("utf-8","ignore")

def dom(url):
    from urllib.parse import urlparse
    return urlparse(url).netloc.lower().replace("www.","")

def info(url):
    try:
        raw=get(url)
        s=BeautifulSoup(raw,"html.parser")
        text=s.get_text(" ",strip=True)
        emails=sorted(set(EMAIL_RE.findall(raw)))
        phones=sorted(set(PHONE_RE.findall(text)))
        socials={"instagram":"","linkedin":""}
        for a in s.find_all("a",href=True):
            u=a["href"]
            if "instagram.com/" in u.lower() and not socials["instagram"]: socials["instagram"]=u
            if "linkedin.com/" in u.lower() and not socials["linkedin"]: socials["linkedin"]=u
        return s.title.get_text(" ",strip=True) if s.title else "",text,emails,phones,socials
    except Exception:return "","","",[],{"instagram":"","linkedin":""}

def search(q):
    url="https://www.google.com/search?q="+quote_plus(q)+"&num=10"
    try:
        raw=get(url)
        s=BeautifulSoup(raw,"html.parser")
        found=[]
        for a in s.select("a"):
            href=a.get("href","")
            if href.startswith("http") and "google." not in href:
                title=a.get_text(" ",strip=True)
                if title and len(title)>5: found.append((title,href))
        return found[:15]
    except Exception:
        return []

def score(title,text,url):
    x=(title+" "+text+" "+url).lower(); n=0
    if "cardiolog" in x or "cardiac" in x or "heart" in x:n+=40
    if "medical" in x or "clinic" in x or "practice" in x:n+=20
    if "virtual assistant" in x or "medical va" in x or "remote assistant" in x:n+=25
    if "hiring" in x or "career" in x or "job" in x or "apply" in x:n+=15
    return min(n,100)

def run(q):
    results={}
    for title,url in search(q):
        d=dom(url)
        if not d or d in results: continue
        t,txt,em,ph,so=info(url)
        public=[e.lower() for e in em if e.lower().split("@")[-1] not in FREE]
        low=(title+" "+txt).lower()
        signals=[]
        for word,label in [("cardiolog","cardiology"),("virtual assistant","virtual assistant"),
                           ("medical va","medical VA"),("hiring","hiring"),("career","careers")]:
            if word in low: signals.append(label)
        results[d]={
          "practice":t or title,"website":url,"email":"; ".join(public[:3]),
          "phone":"; ".join(ph[:2]),"instagram":so["instagram"],
          "linkedin":so["linkedin"],"signal":", ".join(dict.fromkeys(signals)),
          "score":score(title,txt,url)
        }
    return sorted(results.values(),key=lambda x:x["score"],reverse=True)

class H(BaseHTTPRequestHandler):
    def send(self,code,ctype,data):
        self.send_response(code);self.send_header("Content-Type",ctype)
        self.send_header("Access-Control-Allow-Origin","*");self.end_headers()
        self.wfile.write(data)
    def do_GET(self):
        p=urlparse(self.path)
        if p.path=="/":
            self.send(200,"text/html; charset=utf-8",open("index.html","rb").read());return
        if p.path=="/api/search":
            q=parse_qs(p.query).get("q",["cardiology virtual assistant USA"])[0]
            self.send(200,"application/json; charset=utf-8",json.dumps(run(q)).encode());return
        self.send(404,"text/plain",b"Not found")

print("Open http://localhost:8080 in your browser")
HTTPServer(("0.0.0.0",8080),H).serve_forever()
